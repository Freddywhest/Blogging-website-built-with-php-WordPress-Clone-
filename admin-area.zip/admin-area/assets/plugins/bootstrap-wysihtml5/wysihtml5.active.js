$(document).ready(function () {
    "use strict"; // Start of use strict
    //bootstrap-wysihtml5
    $('#some-textarea').wysihtml5();
});