<? $page_name = 'About Page'; ?>
<?php require_once('./news-vendors/main.php'); ?>
    </head>
    <?php require_once('./news-vendors/header.php'); ?><!--/.profile element-->
                <?php require_once('./news-vendors/about-nav.php'); ?>
            <!-- Page Content  -->
			<?php
				if(isset($_SESSION['login']) && $_SESSION['user_role'] == 'admin'){
					}else{
						header("Location: 505.php");
						}
			?>
            <div class="content-wrapper">
                <div class="main-content">
                    <?php require_once('./news-vendors/top-nav.php'); ?><!--/.navbar--><!--/.navbar-->
                    <!--Content Header (Page header)-->
                    <div class="content-header row align-items-center m-0">
                        <nav aria-label="breadcrumb" class="col-sm-4 order-sm-last mb-3 mb-sm-0 p-0 ">
                            <ol class="breadcrumb d-inline-flex font-weight-600 fs-13 bg-white mb-0 float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active">About</li>
                            </ol>
                        </nav>
                        <div class="col-sm-8 header-title p-0">
                            <div class="media">
                                <div class="header-icon text-success mr-3"><i class="fa fa-edit"></i></div>
                                <div class="media-body">
                                    <h1 class="font-weight-bold" <?php echo $name == "style"?"primary":""; ?><?php echo $name != "style"?'style="color:black"':""; ?>>Edit About</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--/.Content Header (Page header)--> 
					<?php
					$sql = "SELECT * FROM about";
					$stmt = $pdo->prepare($sql);
					$stmt->execute();
					while($about = $stmt->fetch(PDO::FETCH_ASSOC)){
						$title = $about['about_title'];
						$detail = $about['about_detail'];
						$about_id = $about['about_id'];
					}
					?>
                    <div class="body-content">
                        <div class="main">
                            <ul class="cbp_tmtimeline">
                                <li>
                                    <time class="cbp_tmtime"><span>About Page</span></time>
                                    <i class="fa fa-edit"></i>
                                    <div class="cbp_tmlabel">
                                        <h4 class="font-weight-bold"><?php echo $title; ?></h4>
                                        <p><?php echo $detail; ?></p>
									<form action="about-page.php" method="POST">
									<input type="hidden" name="about-id" value="<?php echo $about_id; ?>">
										<button type="submit" name="edit-about" class="btn btn-<?php echo $name == "style"?"primary":""; ?><?php echo $name != "style"?"{$name}":""; ?> w-100p mb-2 mr-1">Edit</button>
									</form>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div><!--/.body content-->
                </div><!--/.main content-->
               <?php require_once('./news-vendors/footer.php'); ?>
        <!--Global script(used by all pages)-->
        <script src="assets/plugins/jQuery/jquery-3.4.1.min.js"></script>
        <script src="assets/dist/js/popper.min.js"></script>
        <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/plugins/metisMenu/metisMenu.min.js"></script>
        <script src="assets/plugins/perfect-scrollbar/dist/perfect-scrollbar.min.js"></script>
        <!-- Third Party Scripts(used by this page)-->

        <!--Page Active Scripts(used by this page)-->

        <!--Page Scripts(used by all page)-->
        <script src="assets/dist/js/sidebar.js"></script>
    </body>
</html>