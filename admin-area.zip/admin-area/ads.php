<? $page_name = 'Ads'; ?>
<?php require_once('./news-vendors/main.php'); ?>
        <!--Third party Styles(used by this page)--> 
        <link href="assets/plugins/summernote/summernote.css" rel="stylesheet">
        <link href="assets/plugins/summernote/summernote-bs4.css" rel="stylesheet">
        <link href="assets/plugins/modals/component.css" rel="stylesheet">
		<script src="https://cdn.ckeditor.com/4.15.1/standard/ckeditor.js"></script>
        <link href="assets/plugins/markdown/bootstrap-markdown.min.css" rel="stylesheet">
        <!--Global Styles(used by all pages)-->
    </head>
   <?php require_once('./news-vendors/header.php'); ?><!--/.profile element-->
                <?php require_once('./news-vendors/ads-nav.php'); ?>
            <!-- Page Content  -->
                <?php
                if(isset($_SESSION['login']) && $_SESSION['user_role'] == 'admin'){
                }else{
                header("Location: 505.php");
                }
                ?>
            <div class="content-wrapper">
                <div class="main-content">
                    <?php require_once('./news-vendors/top-nav.php'); ?><!--/.navbar-->
                    <!--Content Header (Page header)-->
                    <div class="content-header row align-items-center m-0">
                        <nav aria-label="breadcrumb" class="col-sm-4 order-sm-last mb-3 mb-sm-0 p-0 ">
                            <ol class="breadcrumb d-inline-flex font-weight-600 fs-13 bg-white mb-0 float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active">Ads</li>
                            </ol>
                        </nav>
                        <div class="col-sm-8 header-title p-0">
                            <div class="media">
                                <div class="header-icon text-success mr-3"><i class="fa fa-money-bill-alt mr-2"></i></div>
                                <div class="media-body">
                                    <h1 class="font-weight-bold" <?php echo $name == "style"?"primary":""; ?><?php echo $name != "style"?'style="color:black"':""; ?>>Ads/Monetization Ads</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--/.Content Header (Page header)--> 
                    <div class="body-content">
                        <div class="card mb-4">
                            <div class="card-body">
                                <div class="modal-text-header">
                                    <h1><i class="fa fa-money-bill-alt mr-2" style="color:blue"></i> Ads Integration <span>Choose where you want to place the ads</span> </h1>
                                </div>
								<? 
									
								?>
                                <div class="row">
                                    <div class="col-sm-12 col-md-6">
                                        <div class="column">
                                            <p class="modal-text">
                                                <ol>
                                                <li><b>Header Ad must be 728px X 90px in size</b></li>
                                                <form action="ads-4.php" method="POST">
                                                   <input type="hidden" value="1" name="ads-id">
                                                  <button name="edit-ads" class="btn btn-<?php echo $name == "style"?"primary":""; ?><?php echo $name != "style"?"{$name}":""; ?> md-trigger md-setperspective mb-2 mr-1" data-modal="modal-17">Header ads</button>
                                                 </form> 
                                                <hr>
                                                  
                                                <li><b>Sidebar Ad must be 300px X 250px in size</b></li>
                                                <form action="ads-4.php" method="POST">
                                                   <input type="hidden" value="2" name="ads-id">
                                                        <button name="edit-ads" class="btn btn-<?php echo $name == "style"?"primary":""; ?><?php echo $name != "style"?"{$name}":""; ?> md-trigger md-setperspective mb-2 mr-1" data-modal="modal-18">Left sidebar ads</button>
                                                </form>
                                                <hr>
                                                
                                                <li><b>Body Ad must be 728px X 90px in size</b></li>
                                                <form action="ads-4.php" method="POST">
                                                   <input type="hidden" value="3" name="ads-id">
                                                        <button name="edit-ads" class="btn btn-<?php echo $name == "style"?"primary":""; ?><?php echo $name != "style"?"{$name}":""; ?> md-trigger md-setperspective mb-2 mr-1" data-modal="modal-19">Body ads</button>
                                                </form>
                                                <hr>
                                                
                                                <li><b>Footer Ad must be 728px X 90px in size</b></li>
                                                <form action="ads-4.php" method="POST">
                                                   <input type="hidden" value="4" name="ads-id">
                                                        <button name="edit-ads" class="btn btn-<?php echo $name == "style"?"primary":""; ?><?php echo $name != "style"?"{$name}":""; ?> md-trigger md-setperspective mb-2 mr-1" data-modal="modal-19"> Footer ads	</button>
                                                </form>
                                                </ol>
                                                </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!--/.body content-->
                </div><!--/.main content-->
                <?php require_once('./news-vendors/footer.php'); ?><!--/.footer content-->
                <div class="overlay"></div>
            </div><!--/.wrapper-->
        </div>
        <!--Global script(used by all pages)-->
      <script src="assets/plugins/jQuery/jquery-3.4.1.min.js"></script>
        <script src="assets/dist/js/popper.min.js"></script>
        <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/plugins/metisMenu/metisMenu.min.js"></script>
        <script src="assets/plugins/perfect-scrollbar/dist/perfect-scrollbar.min.js"></script>
        <!-- Third Party Scripts(used by this page)-->
        <script src="assets/plugins/modals/classie.js"></script>
        <script src="assets/plugins/modals/modalEffects.js"></script>
        <script src="assets/plugins/summernote/summernote.min.js"></script>
        <script src="assets/plugins/summernote/summernote-bs4.min.js"></script>
        <script src="assets/plugins/markdown/bootstrap-markdown.js"></script>
        <!--Page Active Scripts(used by this page)-->
        <script src="assets/plugins/summernote/summernote.active.js"></script>
        <!--Page Active Scripts(used by this page)-->
        <!--Page Scripts(used by all page)-->
        <script src="assets/dist/js/sidebar.js"></script>
    </body>
</html>