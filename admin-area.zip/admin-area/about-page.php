<? $page_name = 'Edit About Page'; ?>
<?php require_once('./news-vendors/main.php'); ?>
        <!--Third party Styles(used by this page)--> 
		<script src="ckeditor/ckeditor.js"></script>
    </head>
  <?php require_once('./news-vendors/header.php'); ?><!--/.profile element-->
                <?php require_once('./news-vendors/about-nav.php'); ?>
            <!-- Page Content  -->
			<?php
				if(isset($_SESSION['login']) && $_SESSION['user_role'] == 'admin'){
					}else{
						header("Location: 505.php");
						}
			?>
			<?php
				$url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URL]";
			?>
            <div class="content-wrapper">
                <div class="main-content">
                   <?php require_once('./news-vendors/top-nav.php'); ?><!--/.navbar--><!--/.navbar-->
                    <!--Content Header (Page header)-->
                    <div class="content-header row align-items-center m-0">
                        <nav aria-label="breadcrumb" class="col-sm-4 order-sm-last mb-3 mb-sm-0 p-0 ">
                            <ol class="breadcrumb d-inline-flex font-weight-600 fs-13 bg-white mb-0 float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active">About Page</li>
                            </ol>
                        </nav>
                        <div class="col-sm-8 header-title p-0">
                            <div class="media">
                                <div class="header-icon text-success mr-3"><i class="typcn typcn-edit mr-2"></i></div>
                                <div class="media-body">
                                    <h1 class="font-weight-bold" <?php echo $name == "style"?"primary":""; ?><?php echo $name != "style"?'style="color:black"':""; ?>>About Page</h1>
                                </div>
                            </div>
                        </div>
                    </div>
					<?php 
					if(isset($_POST['edit-about'])){
						$about_id = $_POST['about-id'];
						$url2 = "{$url}/admin-area/about-page.php?about_id={$about_id}";
						header("Location: {$url2}");
					}
					?>
                    <!--/.Content Header (Page header)--> 
                    <div class="body-content">
						<div class="body-content">
                         <div class="row">
                            <div class="col-md-12 col-lg-12">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <h6 class="fs-17 font-weight-600 mb-0">About Page</h6>
                                            </div>
                                        </div>
                                    </div>
									<?php
									$sql = "SELECT * FROM about WHERE about_id =:id";
									$stmt = $pdo->prepare($sql);
									$stmt->execute([
									':id' => $_GET['about_id']
									]);
									while($about = $stmt->fetch(PDO::FETCH_ASSOC)){
										$title = $about['about_title'];
										$detail = $about['about_detail'];
										$about_id = $about['about_id'];
									}
									?>
									<?php 
									if(isset($_POST['save'])){
										$title = $_POST['title'];
										$detail = $_POST['detail'];
										
										$sql = "UPDATE about SET about_detail =:detail, about_title =:title WHERE about_id =:id";
										$stmt = $pdo->prepare($sql);
										$stmt->execute([
										':detail' => $detail,
										':title' => $title,
										':id' => $_GET['about_id']
										]);
										$success = true;
										header("Refresh:5;url=about.php");
									}
									?>
                                    <div class="card-body">
									<?php
										if(isset($success)){
											 echo "<p class='alert alert-success'>About page have successfully updated,<b> You will be redirect in 5 seconds... </b>
														  <span class='spinner-grow spinner-grow-sm' role='status' aria-hidden='true'></span>
													</p>";
										}
										?>
									<form action="about-page.php?about_id=<?php echo $_GET['about_id']; ?>" method="POST">
                                        <div class="form-group row">
                                            <label for="example-email-input" class="col-sm-3 col-form-label font-weight-600">Title</label>
                                            <div class="col-sm-8">
                                                <input class="form-control" value="<?php echo $title; ?>" name="title" type="text"  placeholder="Title" id="title">
                                            </div>
                                        </div>
										<div class="form-group row">
										<label for="exampleFormControlFile1" class="col-sm-3 col-form-label font-weight-600">Details</label>
											<div class="col-sm-8">
												<textarea name="detail"><?php echo $detail; ?></textarea>
												<script>
														CKEDITOR.replace( 'detail' );
												</script>
											</div>
										</div>
										<p  align="right"><button type="submit" name="save" class="btn btn-<?php echo $name == "style"?"primary":""; ?><?php echo $name != "style"?"{$name}":""; ?> w-100p mb-2 mr-1">Save</button></p>
                                  </form>
                                </div>
                            </div>   
                        </div>
                    </div><!--/.body content-->
                </div>
                        
                    </div><!--/.body content-->
                </div><!--/.main content-->
                <?php require_once('./news-vendors/footer.php'); ?>
        <!--Global script(used by all pages)-->
       <script src="assets/plugins/jQuery/jquery-3.4.1.min.js"></script>
        <script src="assets/dist/js/popper.min.js"></script>
        <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/plugins/metisMenu/metisMenu.min.js"></script>
        <script src="assets/plugins/perfect-scrollbar/dist/perfect-scrollbar.min.js"></script>
        <!-- Third Party Scripts(used by this page)-->
        <script src="assets/plugins/summernote/summernote.min.js"></script>
        <script src="assets/plugins/summernote/summernote-bs4.min.js"></script>
        <!--Page Active Scripts(used by this page)-->
        <script src="assets/plugins/summernote/summernote.active.js"></script>
        <!--Page Scripts(used by all page)-->
        <script src="assets/dist/js/sidebar.js"></script>
		
		<script src="assets/dist/js/speakingurl.min.js"></script>
		<script src="assets/dist/js/slugify.min.js"></script>
		<script>
			jQuery(function ($) {
				$("#slug").slugify("#title", {
					separator: '-',			// If you want to change separator from hyphen (-) to underscore (_).
				});
			});
		</script>

    </body>
</html>