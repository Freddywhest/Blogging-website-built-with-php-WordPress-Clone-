<!-- Required meta tags -->
	<? $page_name = 'Comment Approval'; ?>
			<?php require_once('./news-vendors/main.php'); ?>
        <!--Third party Styles(used by this page)--> 
        <link href="assets/plugins/icheck/skins/all.css" rel="stylesheet">
    </head>
   <?php require_once('./news-vendors/header.php'); ?><!--/.profile element-->
               <?php require_once('./news-vendors/com-nav.php'); ?>
            <div class="content-wrapper">
                <div class="main-content">
                     <?php require_once('./news-vendors/top-nav.php'); ?><!--/.navbar-->
					  <div class="content-header row align-items-center m-0">
                        <nav aria-label="breadcrumb" class="col-sm-4 order-sm-last mb-3 mb-sm-0 p-0 ">
                            <ol class="breadcrumb d-inline-flex font-weight-600 fs-13 bg-white mb-0 float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active">Comments</li>
                            </ol>
                        </nav>
                        <div class="col-sm-8 header-title p-0">
                            <div class="media">
                                <div class="header-icon text-success mr-3"><i class="typcn typcn-puzzle-outline"></i></div>
                                <div class="media-body">
                                    <h1 class="font-weight-bold" <?php echo $name == "style"?"primary":""; ?><?php echo $name != "style"?'style="color:black"':""; ?>>Comments</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="body-content">
                        <div class="mailbox">
						<div class="mailbox-header d-flex align-items-center justify-content-between">
                                <div class="inbox-avatar-wrap d-flex align-items-center"><img src="assets/dist/img/logo3.png" class="inbox-avatar border-green" alt="">
                                    <div class="inbox-avatar-text d-none d-sm-inline-block ml-3">
                                        <h6 class="avatar-name mb-0">Approved comments</h6>
                                    </div>
                                </div>
                            </div>
                            <div class="mailbox-body">
                                <div class="row m-0">
                                    <div class="col-lg-3 p-0 inbox-nav d-none d-lg-block">
                                        <div class="mailbox-sideber">
                                            <div class="profile-usermenu">
                                                <h6 class="fs-13 font-weight-bold">Approved comments</h6>
                                                <ul class="nav flex-column">
                                                    <li class="nav-item"><a href="comment.php"><i class="far fa-comment"></i>All comments </a></li>
                                                    <li class="nav-item active"><a href="approved.php"><i class="fas fa-comment"></i>Approved comments</a></li>
                                                    <li class="nav-item"><a href="unapproved.php"><i class="fas fa-comment-slash"></i>Unapproved comments</a></li>
                                                </ul>
												<hr>
												 <ul class="nav flex-column">
                                                    <li class="nav-item"><a href="replied-comment.php"><i class="fa fa-reply"></i>Replied comments</a></li>
                                                    <li class="nav-item"><a href="not-replied.php"><i class="fa fa-times"></i>Unreplied comments</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-12 col-lg-9 p-0 inbox-mail">
                                        <div class="mailbox-content">
										<?php
											if(isset($_SESSION['login']) && $_SESSION['user_role'] == 'admin'){?>
										<tbody>
										<?php 
										$sql = "SELECT * FROM comments WHERE com_status =:status";
										$stmt = $pdo->prepare($sql);
										$stmt->execute([
										':status' => 'approved'
										]);
										 $post_count = $stmt->rowCount();
											$post_per_page = 7;
											if (isset($_GET['page'])) {
												$page = $_GET['page'];
												if($page == 1) {
													$page_id = 0;
												} else {
													$page_id = ($page * $post_per_page) - $post_per_page;
												}
											} else {
												$page = 1;
												$page_id = 0;
											}
											$total_pager = ceil($post_count / $post_per_page);?>
										<?php
										$sql = "SELECT * FROM comments WHERE com_status =:status  LIMIT $page_id, $post_per_page";
										$stmt = $pdo->prepare($sql);
										$stmt->execute([
										':status' => 'approved'
										]);
										while($comments = $stmt->fetch(PDO::FETCH_ASSOC)){
											$com_id = $comments['com_id'];
											$com_user_name = $comments['com_user_name'];
											$com_user_email = $comments['com_user_email'];
											$com_date = $comments['com_date'];
											$com_detail = $comments['com_detail'];
											$com_status = $comments['com_status'];
											$com_post_id = $comments['com_post_id'];
											
											$sql2 = "SELECT * FROM posts WHERE post_id =:id";
											$stmt2 = $pdo->prepare($sql2);
											$stmt2->execute([
											'id' => $com_post_id
											]);
											$post = $stmt2->fetch(PDO::FETCH_ASSOC);
											$post_id = $post['post_id'];
											$post_title = $post['post_title'];
											
											$sql2 = "SELECT * FROM hot_news WHERE hot_post_id =:id";
											$stmt2 = $pdo->prepare($sql2);
											$stmt2->execute([
											'id' => $com_post_id
											]);
											$post = $stmt2->fetch(PDO::FETCH_ASSOC);
											$post_id = $post['hot_post_id'];
											$hot_post_title = $post['hot_post_title'];?>
											
												<? if($com_status == 'unapproved'){ ?>
												<b>
                                            <div data-href="comment_detail.php?com_id=<? echo $com_id; ?>" class="inbox_item d-flex align-items-center">
                                                <img src="assets/dist/img/avatar.png" class="inbox-avatar d-none d-xl-block mr-2" alt="">
                                                <div class="inbox-avatar-text">
                                                    <h6 class="avatar-name fs-15 font-weight-600 mb-0"><b><? echo $com_user_name; ?></b></h6>
                                                    <div><span><? echo $com_detail; ?></span></div>
                                                </div>
                                                <div class="d-none d-xl-block ml-auto">
                                                    <div class="date"><span class="bg-red badge avatar-text">Unapproved</span><br><b><small><? echo $com_date; ?></small></b></div>
                                                </div>
                                            </div>
											</b>
												<? }else{ ?>
												<div data-href="comment_detail.php?com_id=<? echo $com_id; ?>" class="inbox_item d-flex align-items-center unread">
                                                <img src="assets/dist/img/avatar.png" class="inbox-avatar d-none d-xl-block mr-2" alt="">
                                                <div class="inbox-avatar-text">
                                                    <h6 class="avatar-name fs-15 font-weight-600 mb-0"><? echo $com_user_name; ?></h6>
                                                    <div><span><? echo $com_detail; ?></span></div>
                                                </div>
                                                <div class="d-none d-xl-block ml-auto">
                                                    <div class="date"><span class="bg-green badge avatar-text">Approved</span><br><small><? echo $com_date; ?></small></div>
                                                </div>
                                            </div>
												<? } ?>
												<? } ?>
												<br>
												<br>
												<?php
												if ($post_count > $post_per_page) { ?>
													<nav aria-label="Page navigation example">
														<ul class="pagination pagination-blog justify-content-center">
															<?php 
																if(isset($_GET['page'])) {
																	$prev = $_GET['page'] - 1;
																} else {
																	$prev = 0;
																}

																if($prev+1 <= 1) {
																	echo '<li class="page-item disabled"><a class="page-link" href="#!" aria-label="Previous"><span aria-hidden="true">&#xAB;</span></a></li>';
																} else {
																	echo '<li class="page-item"><a class="page-link" href="approved.php?page='. $prev .'" aria-label="Previous"><span aria-hidden="true">&#xAB;</span></a></li>';
																}
															?>

															<?php 
																if (isset($_GET['page'])) {
																	$active = $_GET['page'];
																} else {
																	$active = 1;
																}
																for ($i = 1; $i <= $total_pager; $i++) {
																	if ($i == $active) {
																		echo '<li class="page-item active"><a class="page-link" href="approved.php?page='. $i .'">' . $i . '</a></li>';
																	} else {
																		echo '<li class="page-item"><a class="page-link" href="approved.php?page='. $i .'">' . $i . '</a></li>';
																	}
																	
																}
															?>

															<?php 
																if(isset($_GET['page'])) {
																	$next = $_GET['page'] + 1;
																} else {
																	$next = 2;
																}

																if($next - 1 >= $total_pager) {
																	echo '<li class="page-item disabled"><a class="page-link" href="#!" aria-label="Next"><span aria-hidden="true">&#xBB;</span></a></li>';
																} else {
																	echo '<li class="page-item"><a class="page-link" href="approved.php?&page=' . $next . '" aria-label="Next"><span aria-hidden="true">&#xBB;</span></a></li>';
																}
															?>
															
														</ul>
													</nav>
												<?php }
											?>
											<? }else{ ?>
											<?php 
												$sql = "SELECT * FROM comments WHERE com_user_id =:id AND com_status =:status";
												$stmt = $pdo->prepare($sql);
												$stmt->execute([
												':id' => $user_id,
												':status' => 'approved'
												]);
												 $post_count = $stmt->rowCount();
													$post_per_page = 7;
													if (isset($_GET['page'])) {
														$page = $_GET['page'];
														if($page == 1) {
															$page_id = 0;
														} else {
															$page_id = ($page * $post_per_page) - $post_per_page;
														}
													} else {
														$page = 1;
														$page_id = 0;
													}
													$total_pager = ceil($post_count / $post_per_page);?>
											<?php
												$sql = "SELECT * FROM comments WHERE com_user_id =:id AND com_status =:status  LIMIT $page_id, $post_per_page";
												$stmt = $pdo->prepare($sql);
												$stmt->execute([
												':id' => $user_id,
												':status' => 'approved'
												]);
												while($comments = $stmt->fetch(PDO::FETCH_ASSOC)){
													$com_id = $comments['com_id'];
													$com_user_name = $comments['com_user_name'];
													$com_user_email = $comments['com_user_email'];
													$com_date = $comments['com_date'];
													$com_detail = $comments['com_detail'];
													$com_status = $comments['com_status'];
													$com_post_id = $comments['com_post_id'];
													
													$sql2 = "SELECT * FROM posts WHERE post_id =:id";
													$stmt2 = $pdo->prepare($sql2);
													$stmt2->execute([
													'id' => $com_post_id
													]);
													$post = $stmt2->fetch(PDO::FETCH_ASSOC);
													$post_id = $post['post_id'];
													$post_title = $post['post_title'];
													
													$sql2 = "SELECT * FROM hot_news WHERE hot_post_id =:id";
													$stmt2 = $pdo->prepare($sql2);
													$stmt2->execute([
													'id' => $com_post_id
													]);
													$post = $stmt2->fetch(PDO::FETCH_ASSOC);
													$post_id = $post['hot_post_id'];
													$hot_post_title = $post['hot_post_title'];?>
                                           
												<? if($com_status == 'unapproved'){ ?>
												<b>
                                            <div data-href="comment_detail.php?com_id=<? echo $com_id; ?>" class="inbox_item d-flex align-items-center">
                                                <img src="assets/dist/img/avatar.png" class="inbox-avatar d-none d-xl-block mr-2" alt="">
                                                <div class="inbox-avatar-text">
                                                    <h6 class="avatar-name fs-15 font-weight-600 mb-0"><b><? echo $com_user_name; ?></b></h6>
                                                    <div><span><? echo $com_detail; ?></span></div>
                                                </div>
                                                <div class="d-none d-xl-block ml-auto">
                                                    <div class="date"><span class="bg-red badge avatar-text">Unapproved</span><br><b><small><? echo $com_date; ?></small></b></div>
                                                </div>
                                            </div>
											</b>
												<? }else{ ?>
												<div data-href="comment_detail.php?com_id=<? echo $com_id; ?>" class="inbox_item d-flex align-items-center unread">
                                                <img src="assets/dist/img/avatar.png" class="inbox-avatar d-none d-xl-block mr-2" alt="">
                                                <div class="inbox-avatar-text">
                                                    <h6 class="avatar-name fs-15 font-weight-600 mb-0"><? echo $com_user_name; ?></h6>
                                                    <div><span><? echo $com_detail; ?></span></div>
                                                </div>
                                                <div class="d-none d-xl-block ml-auto">
                                                    <div class="date"><span class="bg-green badge avatar-text">Approved</span><br><small><? echo $com_date; ?></small></div>
                                                </div>
                                            </div>
												<? } ?>
												<? } ?>
												<br>
												<br>
												<?php
												if ($post_count > $post_per_page) { ?>
													<nav aria-label="Page navigation example">
														<ul class="pagination pagination-blog justify-content-center">
															<?php 
																if(isset($_GET['page'])) {
																	$prev = $_GET['page'] - 1;
																} else {
																	$prev = 0;
																}

																if($prev+1 <= 1) {
																	echo '<li class="page-item disabled"><a class="page-link" href="#!" aria-label="Previous"><span aria-hidden="true">&#xAB;</span></a></li>';
																} else {
																	echo '<li class="page-item"><a class="page-link" href="approved.php?page='. $prev .'" aria-label="Previous"><span aria-hidden="true">&#xAB;</span></a></li>';
																}
															?>

															<?php 
																if (isset($_GET['page'])) {
																	$active = $_GET['page'];
																} else {
																	$active = 1;
																}
																for ($i = 1; $i <= $total_pager; $i++) {
																	if ($i == $active) {
																		echo '<li class="page-item active"><a class="page-link" href="approved.php?page='. $i .'">' . $i . '</a></li>';
																	} else {
																		echo '<li class="page-item"><a class="page-link" href="approved.php?page='. $i .'">' . $i . '</a></li>';
																	}
																	
																}
															?>

															<?php 
																if(isset($_GET['page'])) {
																	$next = $_GET['page'] + 1;
																} else {
																	$next = 2;
																}

																if($next - 1 >= $total_pager) {
																	echo '<li class="page-item disabled"><a class="page-link" href="#!" aria-label="Next"><span aria-hidden="true">&#xBB;</span></a></li>';
																} else {
																	echo '<li class="page-item"><a class="page-link" href="approved.php?&page=' . $next . '" aria-label="Next"><span aria-hidden="true">&#xBB;</span></a></li>';
																}
															?>
															
														</ul>
													</nav>
												<?php }
											?>
												<? } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!--/.body content-->
                </div><!--/.main content-->
               <?php require_once('./news-vendors/footer.php'); ?>
        <!--Global script(used by all pages)-->
        <script src="assets/plugins/jQuery/jquery-3.4.1.min.js"></script>
        <script src="assets/dist/js/popper.min.js"></script>
        <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/plugins/metisMenu/metisMenu.min.js"></script>
        <script src="assets/plugins/perfect-scrollbar/dist/perfect-scrollbar.min.js"></script>
        <!-- Third Party Scripts(used by this page)-->
        <script src="assets/plugins/icheck/icheck.min.js"></script>
        <!--Page Active Scripts(used by this page)-->
        <script src="assets/dist/js/pages/mailbox.active.js"></script>
        <!--Page Scripts(used by all page)-->
        <script src="assets/dist/js/sidebar.js"></script>
    </body>
</html>