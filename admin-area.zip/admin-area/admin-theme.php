<? $page_name = 'Admin Theme'; ?>
<?php require_once('./news-vendors/main.php'); ?>
        <!--Third party Styles(used by this page)--> 
    </head>
  <?php require_once('./news-vendors/header.php'); ?><!--/.profile element-->
                <?php require_once('./news-vendors/admin-nav.php'); ?>
            <!-- Page Content  -->
            <div class="content-wrapper">
                <div class="main-content">
                   <?php require_once('./news-vendors/top-nav.php'); ?><!--/.navbar--><!--/.navbar-->
                    <!--Content Header (Page header)-->
					<?php
						if(isset($_SESSION['login']) && $_SESSION['user_role'] == 'admin'){
							}else{
								header("Location: 505.php");
								}
					?>
                    <div class="content-header row align-items-center m-0">
                        <nav aria-label="breadcrumb" class="col-sm-4 order-sm-last mb-3 mb-sm-0 p-0 ">
                            <ol class="breadcrumb d-inline-flex font-weight-600 fs-13 bg-white mb-0 float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active">Permissions</li>
                            </ol>
                        </nav>
                        <div class="col-sm-8 header-title p-0">
                            <div class="media">
                                <div class="header-icon text-success mr-3"><i class="typcn typcn-key mr-2"></i></div>
                                <div class="media-body">
                                    <h1 class="font-weight-bold" <?php echo $name == "style"?"primary":""; ?><?php echo $name != "style"?'style="color:black"':""; ?>>Edit Permissions</h1>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--/.Content Header (Page header)--> 
                    <div class="body-content">
						<div class="body-content">
                         <div class="row">
                            <div class="col-md-12 col-lg-6">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <h6 class="fs-17 font-weight-600 mb-0">Edit Permissions</h6>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-body">
									<?php
									$sql = "SELECT * FROM admin_theme";
									$stmt = $pdo->prepare($sql);
									$stmt->execute();
									while($theme = $stmt->fetch(PDO::FETCH_ASSOC)){
										$theme_id = $theme['theme_id'];
										$name = $theme['theme_name'];
									}
									?>
                                     <table class="table display table-bordered table-striped table-hover basic">
										<tbody>
                                            <tr>
                                                <td>Current theme</td>
                                                <td><?php echo $name == "danger"?"Red theme":""; ?><?php echo $name == "warning"?"Yellow theme":""; ?><?php echo $name == "success"?"Green theme":""; ?><?php echo $name == "primary"?"Blue theme":""; ?><?php echo $name == "style"?"Default theme":""; ?></td>
											</tr>
										</tbody>
										</table>
										<form action="admin-themepage.php" method="POST">
										<input name="theme-id" type="hidden" value="<?php echo $theme_id; ?>">
                                         <button type="submit" name="edit-theme" class="btn btn-<?php echo $name == "style"?"primary":""; ?><?php echo $name != "style"?"{$name}":""; ?> w-100p mb-2 mr-1">Edit</button>
										</form>
								</div>
                            </div>   
                        </div>
                    </div><!--/.body content-->
                </div>
                        
                    </div><!--/.body content-->
                </div><!--/.main content-->
                <?php require_once('./news-vendors/footer.php'); ?>
        <!--Global script(used by all pages)-->
       <script src="assets/plugins/jQuery/jquery-3.4.1.min.js"></script>
        <script src="assets/dist/js/popper.min.js"></script>
        <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/plugins/metisMenu/metisMenu.min.js"></script>
        <script src="assets/plugins/perfect-scrollbar/dist/perfect-scrollbar.min.js"></script>
        <!-- Third Party Scripts(used by this page)-->
        <script src="assets/plugins/summernote/summernote.min.js"></script>
        <script src="assets/plugins/summernote/summernote-bs4.min.js"></script>
        <!--Page Active Scripts(used by this page)-->
        <script src="assets/plugins/summernote/summernote.active.js"></script>
        <!--Page Scripts(used by all page)-->
        <script src="assets/dist/js/sidebar.js"></script>
		
		<script src="assets/dist/js/speakingurl.min.js"></script>
		<script src="assets/dist/js/slugify.min.js"></script>
		<script>
			jQuery(function ($) {
				$("#slug").slugify("#title", {
					separator: '-',			// If you want to change separator from hyphen (-) to underscore (_).
				});
			});
		</script>

    </body>
</html>