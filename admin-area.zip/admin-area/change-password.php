<? $page_name = 'Profile'; ?>
 <!--Third party Styles(used by this page)--> 
		<?php require_once('./news-vendors/main.php'); ?>
    </head>
<?php require_once('./news-vendors/header.php'); ?><!--/.profile element-->
<?php require_once('./news-vendors/profile-nav.php'); ?><!-- sidebar-body -->
            <!-- Page Content  -->
            <div class="content-wrapper">
                <div class="main-content">
                  <?php require_once('./news-vendors/top-nav.php'); ?>
                    <div class="content-header row align-items-center m-0">
                        <nav aria-label="breadcrumb" class="col-sm-4 order-sm-last mb-3 mb-sm-0 p-0 ">
                            <ol class="breadcrumb d-inline-flex font-weight-600 fs-13 bg-white mb-0 float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item"><a href="#">Forms</a></li>
                                <li class="breadcrumb-item active">Form mask</li>
                            </ol>
                        </nav>
                        <div class="col-sm-8 header-title p-0">
                            <div class="media">
                                <div class="header-icon text-success mr-3"><i class="typcn typcn-key-outline"></i></div>
                                <div class="media-body">
                                    <h1 class="font-weight-bold">Change Password</h1>
                                    <small></small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--/.Content Header (Page header)--> 
                    <div class="body-content">
                        <div class="card">
                            <div class="card-header">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="fs-17 font-weight-600 mb-0">Change Password</h6>
                                    </div>
                                </div>
                            </div>
							
							 <?
								if(isset($_POST['reset'])) {
									$password = trim($_POST['password']);
									$confirm_password = trim($_POST['confirm-password']);
									$user_id = $_POST['id'];
									$show = "new password";
									if($password == $confirm_password) {
										$hash_password = password_hash($password, PASSWORD_BCRYPT, ['cost'=>10]);
										$sql = "UPDATE users SET user_password = :password, act =:act WHERE user_id = :id";
										$stmt = $pdo->prepare($sql);
										$stmt->execute([
											':password' => $hash_password,
											':act' => 1,
											':id' => $user_id
										]);
										echo "<p align='center' class='alert alert-success'>Password updated! <br>You will be redirect to Login page in 2 seconds</p>";
										header("Refresh:2;url=signout.php");
									} else {
										echo "<p  align='center' class='alert alert-danger text-center'>Password doesn't match!</p>";
									}
								}
							?>
							<form action="change-password.php" method="POST" role="form">
                            <div class="card-body">
                                <div class="form-group row">
                                    <label for="date" class="col-lg-3 col-sm-12 col-form-label font-weight-600"></label>
                                    <div class="col-lg-5 col-md-12 col-sm-12">
                                        <div class="text-muted">New password</div>
										<input class="form-control form-control-name" value="<? echo $user_id; ?>" name="id" type="hidden">
                                        <input type="password" class="form-control form-control-email" name="password" class="date form-control"/>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="time" class="col-lg-3 col-sm-12 col-form-label font-weight-600"></label>
                                    <div class="col-lg-5 col-md-12 col-sm-12">
                                        <div class="text-muted">Confirm password</div>
                                        <input class="form-control form-control-email" type="password" name="confirm-password" class="time form-control"/>
                                    </div>
                                </div>
								<div class="text-center">
							<button class="btn btn-primary solid blank" name="reset" type="submit">Change Password</button> 
						</div>
                        </div>
						</form>
                        </div>
                    </div><!--/.body content-->
                </div><!--/.main content-->
               <?php require_once('./news-vendors/footer.php'); ?>
        <!--Global script(used by all pages)-->
        <script data-cfasync="false" src="cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/plugins/jQuery/jquery-3.4.1.min.js"></script>
        <script src="assets/dist/js/popper.min.js"></script>
        <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/plugins/metisMenu/metisMenu.min.js"></script>
        <script src="assets/plugins/perfect-scrollbar/dist/perfect-scrollbar.min.js"></script>
        <!-- Third Party Scripts(used by this page)-->
        <script src="assets/plugins/jQuery-mask-plugin/jquery.mask.min.js"></script>
        <script src="assets/plugins/jQuery-mask-plugin/examples.js"></script>
        <!--Page Active Scripts(used by this page)-->

        <!--Page Scripts(used by all page)-->
        <script src="assets/dist/js/sidebar.js"></script>
    </body>

<!-- Mirrored from bhulua.thememinister.com/forms_mask.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 02 Nov 2020 15:59:36 GMT -->
</html>