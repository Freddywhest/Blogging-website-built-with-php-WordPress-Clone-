<?php require_once ('news-vendors/db.php');
?> 
<!doctype html>
<html lang="en">
<head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="Responsive Bootstrap 4 Admin &amp; Dashboard Template">
        <meta name="author" content="Bdtask">
        <title>MLIG || 505 Page</title>
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/dist/img/favicon.png">
        <!--Global Styles(used by all pages)-->
        <link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/plugins/metisMenu/metisMenu.min.css" rel="stylesheet">
        <link href="assets/plugins/fontawesome/css/all.min.css" rel="stylesheet">
        <link href="assets/plugins/typicons/src/typicons.min.css" rel="stylesheet">
        <link href="assets/plugins/themify-icons/themify-icons.min.css" rel="stylesheet">
        <!--Third party Styles(used by this page)--> 

        <!--Start Your Custom Style Now-->
        <?php 
		$sql = "SELECT * FROM admin_theme";
		$stmt = $pdo->prepare($sql);
		$stmt->execute();
		while($theme = $stmt->fetch(PDO::FETCH_ASSOC)){
			$name = $theme['theme_name'];
			$theme_id = $theme['theme_id'];
		}
		?>
        <link href="assets/dist/css/<?php echo $name; ?>.css" rel="stylesheet">
    </head>
    <body class="bg-white">
        <section class="page_505 d-flex align-items-center justify-content-center text-center h-100vh">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="four_zero_four_bg">
                            <h1 class="font-weight-bold text-monospace">505</h1>
                        </div>
                        <div class="contant_box_505">
                            <h3 class="h2">You do not have permission to go to this page.</h3>
                            <p> We apologize. You can go back to main page:</p>
                            <a href="signout.php" class="btn btn-success mt-3">Go back</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Global Theme Bundle(used by all pages)-->
        <script src="assets/plugins/jQuery/jquery-3.4.1.min.js"></script>
        <!-- Third Party Scripts(used by this page)-->
        <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    </body>
</html>